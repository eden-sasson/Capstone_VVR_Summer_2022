﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaypointData : MonoBehaviour
{
    public Vector3 nodePosition = new Vector3();
}
